#include "test_main.h"

START_TEST(tc_s21_sprintf_accurancy_1) {
  char buffer[20];
  int test_int = 123;
  sprintf(buffer, "%.5d", test_int);
  char buffer1[20];
  int test_int1 = 123;
  s21_sprintf(buffer1, "%.5d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_accurancy_2) {
  char buffer[20];
  float test_float = 3.14159;
  sprintf(buffer, "%.3f", test_float);
  char buffer1[20];
  float test_float1 = 3.14159;
  s21_sprintf(buffer1, "%.3f", test_float1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_accurancy_3) {
  char buffer[20];
  char *test_string = "Hello, World!";
  sprintf(buffer, "%.5s", test_string);
  char buffer1[20];
  char *test_string1 = "Hello, World!";
  s21_sprintf(buffer1, "%.5s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_accurancy(void) {
  Suite *s = suite_create("test_s21_sprintf_accurancy");
  TCase *tc = tcase_create("test_s21_sprintf_accurancy_case");
  tcase_add_test(tc, tc_s21_sprintf_accurancy_1);
  tcase_add_test(tc, tc_s21_sprintf_accurancy_2);
  tcase_add_test(tc, tc_s21_sprintf_accurancy_3);
  suite_add_tcase(s, tc);
  return (s);
}