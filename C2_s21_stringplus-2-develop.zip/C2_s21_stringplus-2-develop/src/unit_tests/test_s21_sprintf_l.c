#include "test_main.h"

// for 32 bits

START_TEST(tc_s21_sprintf_l_1) {
  char buffer[50];
  long int test_long = 1234567890L;
  sprintf(buffer, "%ld", test_long);
  char buffer1[50];
  long int test_long1 = 1234567890L;
  s21_sprintf(buffer1, "%ld", test_long1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_l_2) {
  char buffer[50];
  long int test_long = -2147483648L;
  sprintf(buffer, "%ld", test_long);
  char buffer1[50];
  long int test_long1 = -2147483648L;
  s21_sprintf(buffer1, "%ld", test_long1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_l_3) {
  char buffer[50];
  long int test_long = 2147483647L;
  sprintf(buffer, "%ld", test_long);
  char buffer1[50];
  long int test_long1 = 2147483647L;
  s21_sprintf(buffer1, "%ld", test_long1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_l_4) {
  char buffer[50];
  unsigned long int test_ulong = 4294967295UL;
  sprintf(buffer, "%lu", test_ulong);
  char buffer1[50];
  unsigned long int test_ulong1 = 4294967295UL;
  s21_sprintf(buffer1, "%lu", test_ulong1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_l(void) {
  Suite *s = suite_create("test_s21_sprintf_l");
  TCase *tc = tcase_create("test_s21_sprintf_l_case");
  tcase_add_test(tc, tc_s21_sprintf_l_1);
  tcase_add_test(tc, tc_s21_sprintf_l_2);
  tcase_add_test(tc, tc_s21_sprintf_l_3);
  tcase_add_test(tc, tc_s21_sprintf_l_4);
  suite_add_tcase(s, tc);
  return (s);
}