#ifndef TEST
#define TEST
#include <check.h>

#include "../s21_string.h"
Suite *test_s21_trim(void);
Suite *test_s21_insert(void);
Suite *test_s21_to_upper(void);
Suite *test_s21_to_lower(void);
Suite *test_s21_memchr(void);    // return void*
Suite *test_s21_memcmp(void);    // return int
Suite *test_s21_memcpy(void);    // return void*
Suite *test_s21_memset(void);    // return void*
Suite *test_s21_strncat(void);   // return char*
Suite *test_s21_strchr(void);    // return char*
Suite *test_s21_strncmp(void);   // return int
Suite *test_s21_strncpy(void);   // return char*
Suite *test_s21_strcspn(void);   // return size_t
Suite *test_s21_strerror(void);  // return char*
Suite *test_s21_strlen(void);    // return size_t
Suite *test_s21_strpbrk(void);   // return char*
Suite *test_s21_strrchr(void);   // return char
Suite *test_s21_strstr(void);    // return char*
Suite *test_s21_strtok(void);    // return char*
Suite *test_s21_sprintf_c(void);
Suite *test_s21_sprintf_d(void);
Suite *test_s21_sprintf_f(void);
Suite *test_s21_sprintf_s(void);
Suite *test_s21_sprintf_u(void);
Suite *test_s21_sprintf_percent(void);
Suite *test_s21_sprintf_minus(void);
Suite *test_s21_sprintf_plus(void);
Suite *test_s21_sprintf_width(void);
Suite *test_s21_sprintf_accurancy(void);
Suite *test_s21_sprintf_h(void);
Suite *test_s21_sprintf_l(void);
Suite *test_s21_sprintf_space(void);
Suite *test_s21_sprintf_g(void);
Suite *test_s21_sprintf_G(void);
Suite *test_s21_sprintf_e(void);
Suite *test_s21_sprintf_E(void);
Suite *test_s21_sprintf_x(void);
Suite *test_s21_sprintf_X(void);
Suite *test_s21_sprintf_o(void);
Suite *test_s21_sprintf_p(void);
Suite *test_s21_sprintf_sharp(void);
Suite *test_s21_sprintf_zero(void);
Suite *test_s21_sprintf_width_star(void);
Suite *test_s21_sprintf_L(void);
Suite *test_s21_sprintf_accurancy_star(void);
Suite *test_s21_sscanf_g(void);
Suite *test_s21_sscanf_G(void);
Suite *test_s21_sscanf_e(void);
Suite *test_s21_sscanf_E(void);
Suite *test_s21_sscanf_x(void);
Suite *test_s21_sscanf_X(void);
Suite *test_s21_sscanf_o(void);
Suite *test_s21_sscanf_p(void);
Suite *test_s21_sscanf_width_star(void);
Suite *test_s21_sscanf_L(void);
Suite *test_s21_sscanf_c(void);
Suite *test_s21_sscanf_d(void);
Suite *test_s21_sscanf_f(void);
Suite *test_s21_sscanf_s(void);
Suite *test_s21_sscanf_u(void);
Suite *test_s21_sscanf_percent(void);
Suite *test_s21_sscanf_width(void);
Suite *test_s21_sscanf_h(void);
Suite *test_s21_sscanf_l(void);
#endif