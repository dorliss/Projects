#include "test_main.h"

START_TEST(tc_21_memcmp_1) {
  char str1[] = "Hello, World";
  char str2[] = "Hello, World";
  ck_assert_int_eq(memcmp(str1, str2, sizeof(str1)),
                   s21_memcmp(str1, str2, sizeof(str1)));
}
END_TEST

START_TEST(tc_21_memcmp_2) {
  char str1[] = " ";
  char str2[] = " ";
  ck_assert_int_eq(memcmp(str1, str2, sizeof(str1)),
                   s21_memcmp(str1, str2, sizeof(str1)));
}
END_TEST

START_TEST(tc_21_memcmp_3) {
  char str1[] = "hi bro \n wol";
  char str2[] = "hi bro \n wol";
  ck_assert_int_eq(memcmp(str1, str2, sizeof(str1)),
                   s21_memcmp(str1, str2, sizeof(str1)));
}
END_TEST

START_TEST(tc_21_memcmp_4) {
  char str1[] = "hi bro \n wol";
  char str2[] = "hi bro \n wol";
  ck_assert_int_eq(memcmp(str1, str2, 8), s21_memcmp(str1, str2, 8));
}
END_TEST

Suite *test_s21_memcmp(void) {
  Suite *s = suite_create("test_s21_memcmp");
  TCase *tc = tcase_create("test_s21_memcmp_case");
  tcase_add_test(tc, tc_21_memcmp_1);
  tcase_add_test(tc, tc_21_memcmp_2);
  tcase_add_test(tc, tc_21_memcmp_3);
  tcase_add_test(tc, tc_21_memcmp_4);
  suite_add_tcase(s, tc);
  return (s);
}