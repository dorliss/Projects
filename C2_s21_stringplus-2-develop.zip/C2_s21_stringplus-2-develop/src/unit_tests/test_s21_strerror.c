
#include "test_main.h"

START_TEST(strerror_1) {
  int i = 1;
  ck_assert_str_eq(strerror(i), s21_strerror(i));
}
END_TEST

START_TEST(strerror_2) {
  int i = 2;
  ck_assert_str_eq(strerror(i), s21_strerror(i));
}
END_TEST

START_TEST(strerror_3) {
  int i = 3;
  ck_assert_str_eq(strerror(i), s21_strerror(i));
}
END_TEST

Suite *test_s21_strerror(void) {
  Suite *s = suite_create("test_s21_strerror");
  TCase *tc = tcase_create("test_s21_insert_strerror");
  tcase_add_test(tc, strerror_1);
  tcase_add_test(tc, strerror_2);
  tcase_add_test(tc, strerror_3);
  suite_add_tcase(s, tc);
  return (s);
}