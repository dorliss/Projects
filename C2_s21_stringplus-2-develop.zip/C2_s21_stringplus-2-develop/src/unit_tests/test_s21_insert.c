#include "test_main.h"

START_TEST(insert_test1) {
  char str[] = "Charles Leclerc";
  char src[] = "I love . He would be a champion in 2023!";
  s21_size_t index = 7;
  char expected[] = "I love Charles Leclerc. He would be a champion in 2023!";
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_str_eq(got, expected);
  if (got) free(got);
}
END_TEST

START_TEST(insert_test2) {
  char str[] = "Charles ";
  char src[] = "Leclerc";
  s21_size_t index = 0;
  char expected[] = "Charles Leclerc";
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_str_eq(got, expected);
  if (got) free(got);
}
END_TEST

START_TEST(insert_test3) {
  char str[] = "";
  char src[] = "";
  s21_size_t index = 100;
  char *expected = S21_NULL;
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_pstr_eq(got, expected);
  if (got) free(got);
}
END_TEST

START_TEST(insert_test4) {
  char *src = S21_NULL;
  char *str = S21_NULL;
  s21_size_t index = 100;
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_ptr_null(got);
  if (got) free(got);
}
END_TEST

START_TEST(insert_test5) {
  char str[] = "Maier!";
  char src[] = "Leven  ";
  s21_size_t index = 6;
  char expected[] = "Leven Maier! ";
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_str_eq(got, expected);
  if (got) free(got);
}
END_TEST

START_TEST(insert_test6) {
  char *str = S21_NULL;
  char src[] = "Zoolander  ";
  s21_size_t index = 0;
  char *got = (char *)s21_insert(src, str, index);
  ck_assert_ptr_null(got);
  if (got) free(got);
}
END_TEST

Suite *test_s21_insert(void) {
  Suite *s = suite_create("test_s21_insert");
  TCase *tc = tcase_create("test_s21_insert_create");
  tcase_add_test(tc, insert_test1);
  tcase_add_test(tc, insert_test2);
  tcase_add_test(tc, insert_test3);
  tcase_add_test(tc, insert_test4);
  tcase_add_test(tc, insert_test5);
  tcase_add_test(tc, insert_test6);
  suite_add_tcase(s, tc);
  return (s);
}