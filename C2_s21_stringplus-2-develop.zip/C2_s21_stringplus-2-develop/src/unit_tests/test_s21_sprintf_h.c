#include "test_main.h"

START_TEST(tc_s21_sprintf_h_1) {
  char buffer[20];
  short int test_short = 12345;
  sprintf(buffer, "%hd", test_short);
  char buffer1[20];
  short int test_short1 = 12345;
  s21_sprintf(buffer1, "%hd", test_short1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_h_2) {
  char buffer[20];
  short int test_short = -32768;
  sprintf(buffer, "%hd", test_short);
  char buffer1[20];
  short int test_short1 = -32768;
  s21_sprintf(buffer1, "%hd", test_short1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_h_3) {
  char buffer[20];
  short int test_short = 32767;  // i can't take bigger
  sprintf(buffer, "%hd", test_short);
  char buffer1[20];
  short int test_short1 = 32767;  // i can't take bigger
  s21_sprintf(buffer1, "%hd", test_short1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_h_4) {
  char buffer[20];
  unsigned short int test_ushort = 32768;
  sprintf(buffer, "%hu", test_ushort);
  char buffer1[20];
  unsigned short int test_ushort1 = 32768;
  s21_sprintf(buffer1, "%hu", test_ushort1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_h_5) {
  char buffer[20];
  short int test_short = 32768;  // if i take bigger)))
  sprintf(buffer, "%hd", test_short);
  char buffer1[20];
  short int test_short1 = 32768;  // if i take bigger)))
  s21_sprintf(buffer1, "%hd", test_short1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_h(void) {
  Suite *s = suite_create("test_s21_sprintf_h");
  TCase *tc = tcase_create("test_s21_sprintf_h_case");
  tcase_add_test(tc, tc_s21_sprintf_h_1);
  tcase_add_test(tc, tc_s21_sprintf_h_2);
  tcase_add_test(tc, tc_s21_sprintf_h_3);
  tcase_add_test(tc, tc_s21_sprintf_h_4);
  tcase_add_test(tc, tc_s21_sprintf_h_5);
  suite_add_tcase(s, tc);
  return (s);
}