#include "test_main.h"
// дописать тесты
START_TEST(tc_s21_strtok_1) {
  char str[] = "apple,banana,cherry";
  const char *str2 = ",";
  char str_copy[sizeof(str)];
  strcpy(str_copy, str);
  char *token = s21_strtok(str_copy, str2);
  ck_assert_str_eq(token, "apple");
  token = s21_strtok(NULL, str2);
  ck_assert_str_eq(token, "banana");
  token = s21_strtok(NULL, str2);
  ck_assert_str_eq(token, "cherry");
  token = s21_strtok(NULL, str2);
  ck_assert_ptr_eq(token, NULL);
}
END_TEST

START_TEST(tc_s21_strtok_2) {
  char str[] = "Hello";
  char *token = strtok(str, ",");
  char *token1 = s21_strtok(str, ",");
  ck_assert_str_eq(token, token1);
}
END_TEST

START_TEST(tc_s21_strtok_3) {
  char str[] = "";
  char *token1 = s21_strtok(str, ",");
  ck_assert_ptr_null(token1);
}
END_TEST

Suite *test_s21_strtok(void) {
  Suite *s = suite_create("test_s21_strtok");
  TCase *tc = tcase_create("test_s21_strtok_case");
  tcase_add_test(tc, tc_s21_strtok_1);
  tcase_add_test(tc, tc_s21_strtok_2);
  tcase_add_test(tc, tc_s21_strtok_3);
  suite_add_tcase(s, tc);
  return (s);
}