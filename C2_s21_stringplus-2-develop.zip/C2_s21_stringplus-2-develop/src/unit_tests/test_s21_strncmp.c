#include "test_main.h"

START_TEST(tc_s21_strncmp_1) {
  ck_assert_int_eq(strncmp("Hello", "Hello", 5),
                   s21_strncmp("Hello", "Hello", 5));
}
END_TEST

START_TEST(tc_s21_strncmp_4) {
  ck_assert_int_eq(strncmp("", "", 5), s21_strncmp("", "", 5));
}
END_TEST

START_TEST(tc_s21_strncmp_5) {
  ck_assert_int_eq(strncmp("Hello", "Hello", 0),
                   s21_strncmp("Hello", "Hello", 0));
}
END_TEST

START_TEST(tc_s21_strncmp_6) {
  ck_assert_int_eq(strncmp("Hi", "Hi", 10), s21_strncmp("Hello", "Hello", 0));
}
END_TEST

Suite *test_s21_strncmp(void) {
  Suite *s = suite_create("test_s21_strncmp");
  TCase *tc = tcase_create("test_s21_strncmp_case");
  tcase_add_test(tc, tc_s21_strncmp_1);
  tcase_add_test(tc, tc_s21_strncmp_4);
  tcase_add_test(tc, tc_s21_strncmp_5);
  tcase_add_test(tc, tc_s21_strncmp_6);
  suite_add_tcase(s, tc);
  return (s);
}