#include "test_main.h"

START_TEST(tc_s21_sprintf_s_1) {
  char buffer[100];
  char *test_string = "Hello, World!";
  sprintf(buffer, "%s", test_string);
  char buffer1[100];
  char *test_string1 = "Hello, World!";
  s21_sprintf(buffer1, "%s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_s_2) {
  char buffer[100];
  char *test_string = "";
  sprintf(buffer, "%s", test_string);
  char buffer1[100];
  char *test_string1 = "";
  s21_sprintf(buffer1, "%s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_s_3) {
  char buffer[100];
  char *test_string =
      "jkskkljsdafkjldsfkjla fkjlfkjad kjfad kkadfadfad faf daf af asdfadf "
      "asaalfjakldfklakldfj lkajdf lka";
  sprintf(buffer, "%s", test_string);
  char buffer1[100];
  char *test_string1 =
      "jkskkljsdafkjldsfkjla fkjlfkjad kjfad kkadfadfad faf daf af asdfadf "
      "asaalfjakldfklakldfj lkajdf lka";
  s21_sprintf(buffer1, "%s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_s_4) {
  char buffer[50] = "Old days";
  sprintf(buffer, "New days");
  char buffer1[50] = "Old days";
  s21_sprintf(buffer1, "New days");
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_s_5) {
  char str1[200];
  char str2[200];
  char *str3 = "%6.5s Test %.23s Test %3.s TEST %.s";
  char *val = "WHAT IS THIS";
  char *val2 = "i don't care anymore, really";
  char *val3 = "PPAP";
  char *val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_s_6) {
  char str1[200];
  char str2[200];
  char *str3 = "%-10.5s Test %-.8s Test %-7s TEST %-.s";
  char *val = "WHAT IS THIS";
  char *val2 = "i don't care anymore, really";
  char *val3 = "PPAP";
  char *val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_s_7) {
  char str1[200];
  char str2[200];
  char *str3 = "%0s Test %0.s Test %0.0s TEST %0s GOD %.s";
  char *val = "WHAT IS THIS";
  char *val2 = "i don't care anymore, really";
  char *val3 = "PPAP";
  char *val4 = "I don't feel so good";
  char *val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_s_8) {
  char str1[200];
  char str2[200];
  char *str3 = "%+s Test %+3.s Test %5.7s TEST %10s";
  char *val = "WHAT IS THIS";
  char *val2 = "i don't care anymore, really";
  char *val3 = "abcd";
  char *val4 = "I don't feel so good";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_s_9) {
  char str1[200];
  char str2[200];
  char *str3 = "% s Test % 3.s Test % 5.7s TEST % 10s GOD %.s";
  char *val = "WHAT IS THIS";
  char *val2 = "i don't care anymore, really";
  char *val3 = "PPAP";
  char *val4 = "I don't feel so good";
  char *val5 = "What is lovin'?!";
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite *test_s21_sprintf_s(void) {
  Suite *s = suite_create("test_s21_sprintf_s");
  TCase *tc = tcase_create("test_s21_sprintf_s_case");
  tcase_add_test(tc, tc_s21_sprintf_s_1);
  tcase_add_test(tc, tc_s21_sprintf_s_2);
  tcase_add_test(tc, tc_s21_sprintf_s_3);
  tcase_add_test(tc, tc_s21_sprintf_s_4);
  tcase_add_test(tc, tc_s21_sprintf_s_5);
  tcase_add_test(tc, tc_s21_sprintf_s_6);
  tcase_add_test(tc, tc_s21_sprintf_s_7);
  tcase_add_test(tc, tc_s21_sprintf_s_8);
  tcase_add_test(tc, tc_s21_sprintf_s_9);
  suite_add_tcase(s, tc);
  return (s);
}