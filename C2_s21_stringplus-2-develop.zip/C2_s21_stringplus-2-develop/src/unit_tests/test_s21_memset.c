#include "test_main.h"

START_TEST(tc_s21_memset_1) {
  char buffer[10];
  s21_memset(buffer, 0, sizeof(buffer));

  for (size_t i = 0; i < sizeof(buffer); ++i) {
    ck_assert_int_eq(buffer[i], 0);
  }
}
END_TEST

START_TEST(tc_s21_memset_2) {
  char buffer[10];
  s21_memset(buffer, 20, sizeof(buffer));

  for (size_t i = 0; i < sizeof(buffer); ++i) {
    ck_assert_int_eq(buffer[i], 20);
  }
}
END_TEST

START_TEST(tc_s21_memset_3) {
  char buffer[10];
  int value = 256;
  s21_memset(buffer, value, sizeof(buffer));
  for (size_t i = 0; i < sizeof(buffer); ++i) {
    ck_assert_int_eq((unsigned char)buffer[i], value % 256);
  }
}
END_TEST

START_TEST(tc_s21_memset_4) {
  char buffer[10];
  int value = -1;
  s21_memset(buffer, value, sizeof(buffer));
  for (size_t i = 0; i < sizeof(buffer); ++i) {
    ck_assert_int_eq((unsigned char)buffer[i], 255);
  }
}
END_TEST

START_TEST(tc_s21_memset_5) {
  size_t size = SIZE_MAX_MEMSET;
  char *buffer = malloc(size);
  if (buffer == NULL) {
    ck_abort_msg("Failed to allocate memory");
  }
  int value = 42;
  s21_memset(buffer, value, size);
  for (size_t i = 0; i < size; ++i) {
    ck_assert_int_eq(buffer[i], value);
  }

  free(buffer);
}
END_TEST

Suite *test_s21_memset(void) {
  Suite *s = suite_create("test_s21_memset");
  TCase *tc = tcase_create("test_s21_memset_case");
  tcase_add_test(tc, tc_s21_memset_1);
  tcase_add_test(tc, tc_s21_memset_2);
  tcase_add_test(tc, tc_s21_memset_3);
  tcase_add_test(tc, tc_s21_memset_4);
  tcase_add_test(tc, tc_s21_memset_5);
  suite_add_tcase(s, tc);
  return (s);
}