#include "test_main.h"

START_TEST(tc_s21_sprintf_c_1) {
  char buffer[10];
  char test_char = 'X';
  sprintf(buffer, "%c", test_char);
  char buffer1[10];
  char test_char1 = 'X';
  s21_sprintf(buffer1, "%c", test_char1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_c_2) {
  char buffer[10];
  char test_char = (char)-128;
  sprintf(buffer, "%c", test_char);
  char buffer1[10];
  char test_char1 = (char)-128;
  s21_sprintf(buffer1, "%c", test_char1);
  ck_assert_int_eq(buffer[0], buffer1[0]);
}
END_TEST

START_TEST(tc_s21_sprintf_c_3) {
  char buffer[10];
  char test_char = 127;
  sprintf(buffer, "%c", test_char);
  char buffer1[10];
  char test_char1 = 127;
  s21_sprintf(buffer1, "%c", test_char1);
  ck_assert_int_eq(buffer[0], buffer1[0]);
}
END_TEST

START_TEST(tc_s21_sprintf_c_4) {
  char str1[100];
  char str2[100];
  char *str3 = "%c Test %c Test %c Test %c Test %c";
  int a = 9;
  int b = 10;
  int c = 17;
  int d = 66;
  int e = 124;
  ck_assert_int_eq(sprintf(str1, str3, a, b, c, d, e),
                   s21_sprintf(str2, str3, a, b, c, d, e));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_5) {
  char str1[100];
  char str2[100];
  char *str3 = "%c Test %c Test %c Test %c Test %c";
  int a = -6;
  int b = -10;
  int c = -17;
  int d = -66;
  int e = -124;
  ck_assert_int_eq(sprintf(str1, str3, a, b, c, d, e),
                   s21_sprintf(str2, str3, a, b, c, d, e));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_6) {
  char str1[100];
  char str2[100];
  char *str3 = "%c Test %c Test %c Test %c Test %c";
  int a = 60;
  int b = 50;
  int c = 1744;
  int d = 386;
  int e = 257;
  ck_assert_int_eq(sprintf(str1, str3, a, b, c, d, e),
                   s21_sprintf(str2, str3, a, b, c, d, e));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_7) {
  char str1[100];
  char str2[100];
  char *str3 = "%c Test %c Test %c Test %c Test %c";
  int a = 60;
  int b = 50;
  int c = 1744;
  int d = 386;
  int e = 257;
  ck_assert_int_eq(sprintf(str1, str3, a, b, c, d, e),
                   s21_sprintf(str2, str3, a, b, c, d, e));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_8) {
  char str1[100];
  char str2[100];
  char *str3 = "%#c Test %#c Test %#c Test %#c Test %#c";
  ck_assert_int_eq(sprintf(str1, str3, ' ', 'n', '5', '%', '\\'),
                   s21_sprintf(str2, str3, ' ', 'n', '5', '%', '\\'));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_9) {
  char str1[400];
  char str2[400];
  char *str3 = "%.7c Test % -.7c Test %- 050c Test %- 54c Test %-0188c";
  int a = 45;
  ck_assert_int_eq(sprintf(str1, str3, a, a, a, a, a),
                   s21_sprintf(str2, str3, a, a, a, a, a));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_c_10) {
  char str1[100];
  char str2[100];
  char *str3 = "%lc Test %c Test %c Test %c Test %c";
  int a = 9;
  int b = 10;
  int c = 17;
  int d = 66;
  int e = 124;
  ck_assert_int_eq(sprintf(str1, str3, a, b, c, d, e),
                   s21_sprintf(str2, str3, a, b, c, d, e));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite *test_s21_sprintf_c(void) {
  Suite *s = suite_create("test_s21_sprintf_c");
  TCase *tc = tcase_create("test_s21_sprintf_c_case");
  tcase_add_test(tc, tc_s21_sprintf_c_1);
  tcase_add_test(tc, tc_s21_sprintf_c_2);
  tcase_add_test(tc, tc_s21_sprintf_c_3);
  tcase_add_test(tc, tc_s21_sprintf_c_4);
  tcase_add_test(tc, tc_s21_sprintf_c_5);
  tcase_add_test(tc, tc_s21_sprintf_c_6);
  tcase_add_test(tc, tc_s21_sprintf_c_7);
  tcase_add_test(tc, tc_s21_sprintf_c_8);
  tcase_add_test(tc, tc_s21_sprintf_c_9);
  tcase_add_test(tc, tc_s21_sprintf_c_10);
  suite_add_tcase(s, tc);
  return (s);
}