#include "test_main.h"

int main() {
  int failed = 0;
  Suite *s21_string_test[] = {test_s21_memchr(),
                              test_s21_memcmp(),
                              test_s21_memcpy(),
                              test_s21_memset(),
                              test_s21_strchr(),
                              test_s21_strcspn(),
                              test_s21_strlen(),
                              test_s21_strncat(),
                              test_s21_strncmp(),
                              test_s21_strncpy(),
                              test_s21_strpbrk(),
                              test_s21_strrchr(),
                              test_s21_strstr(),
                              test_s21_strtok(),
                              test_s21_sprintf_c(),
                              test_s21_sprintf_d(),
                              test_s21_strerror(),
                              test_s21_sprintf_f(),
                              test_s21_sprintf_h(),
                              test_s21_sprintf_l(),
                              test_s21_sprintf_s(),
                              test_s21_sprintf_u(),
                              test_s21_sprintf_minus(),
                              test_s21_sprintf_plus(),
                              test_s21_sprintf_space(),
                              test_s21_sprintf_width(),
                              test_s21_sprintf_percent(),
                              test_s21_sprintf_accurancy(),
                              test_s21_to_lower(),
                              test_s21_to_upper(),
                              test_s21_insert(),
                              test_s21_trim(),
                              NULL};
  for (int i = 0; s21_string_test[i] != NULL; i++) {
    SRunner *sr = srunner_create(s21_string_test[i]);
    srunner_set_fork_status(sr, CK_NOFORK);
    srunner_run_all(sr, CK_NORMAL);
    failed += srunner_ntests_failed(sr);
    srunner_free(sr);
  }
  printf("Failed: %d\n", failed);
  return 0;
}
