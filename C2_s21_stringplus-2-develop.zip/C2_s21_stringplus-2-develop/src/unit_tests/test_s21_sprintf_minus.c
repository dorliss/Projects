#include "test_main.h"

START_TEST(tc_s21_sprintf_minus_1) {
  char buffer[20];
  int test_int = 123;
  sprintf(buffer, "%-3d", test_int);
  char buffer1[20];
  int test_int1 = 123;
  s21_sprintf(buffer1, "%-3d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_minus_2) {
  char buffer[20];
  char *test_str = "test";
  sprintf(buffer, "%-10s", test_str);
  char buffer1[20];
  char *test_str1 = "test";
  s21_sprintf(buffer1, "%-10s", test_str1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_minus_3) {
  char buffer[20];
  char *test_str = "test";
  sprintf(buffer, "%-2s", test_str);
  char buffer1[20];
  char *test_str1 = "test";
  s21_sprintf(buffer1, "%-2s", test_str1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_minus(void) {
  Suite *s = suite_create("test_s21_sprintf_minus");
  TCase *tc = tcase_create("test_s21_sprintf_minus_case");
  tcase_add_test(tc, tc_s21_sprintf_minus_1);
  tcase_add_test(tc, tc_s21_sprintf_minus_2);
  tcase_add_test(tc, tc_s21_sprintf_minus_3);
  suite_add_tcase(s, tc);
  return (s);
}