#include "test_main.h"

START_TEST(tc_s21_strncat_1) {
  char dest[20] = "Hello";
  char *src = " World";
  strncat(dest, src, 6);
  char dest1[20] = "Hello";
  char *src1 = " World";
  s21_strncat(dest1, src1, 6);
  ck_assert_str_eq(dest, dest1);
}
END_TEST

START_TEST(tc_s21_strncat_2) {
  char dest[30] = "Hello";
  char *src = " World";
  strncat(dest, src, 20);
  char dest1[30] = "Hello";
  char *src1 = " World";
  s21_strncat(dest1, src1, 20);
  ck_assert_str_eq(dest, dest1);
}
END_TEST

START_TEST(tc_s21_strncat_3) {
  char dest[20] = "Hello";
  char *src = " World";
  strncat(dest, src, 0);  // n равно 0
  char dest1[20] = "Hello";
  char *src1 = " World";
  s21_strncat(dest1, src1, 0);  // n равно 0
  ck_assert_str_eq(dest, dest1);
}
END_TEST

START_TEST(tc_s21_strncat_4) {
  char dest[20] = "Hello";
  char *src = "";
  strncat(dest, src, 5);
  char dest1[20] = "Hello";
  char *src1 = "";
  s21_strncat(dest1, src1, 5);
  ck_assert_str_eq(dest, dest1);
}
END_TEST

Suite *test_s21_strncat(void) {
  Suite *s = suite_create("test_s21_strncat");
  TCase *tc = tcase_create("test_s21_strncat_case");
  tcase_add_test(tc, tc_s21_strncat_1);
  tcase_add_test(tc, tc_s21_strncat_2);
  tcase_add_test(tc, tc_s21_strncat_3);
  tcase_add_test(tc, tc_s21_strncat_4);
  suite_add_tcase(s, tc);
  return (s);
}