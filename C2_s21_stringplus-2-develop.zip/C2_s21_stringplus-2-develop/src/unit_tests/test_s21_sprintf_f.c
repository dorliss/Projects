#include "test_main.h"

START_TEST(tc_s21_sprintf_f_1) {
  char buffer[50];
  double test_float = 123.456;
  sprintf(buffer, "%f", test_float);
  char buffer1[50];
  double test_float1 = 123.456;
  s21_sprintf(buffer1, "%f", test_float1);
  ck_assert_str_eq(buffer, buffer1);  // 6 deffault after point
}
END_TEST

START_TEST(tc_s21_sprintf_f_2) {
  char buffer[50];
  double test_float = 0.000123;
  sprintf(buffer, "%f", test_float);
  char buffer1[50];
  double test_float1 = 0.000123;
  s21_sprintf(buffer1, "%f", test_float1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_f_3) {
  char buffer[50];
  double test_float = 12345678.9;
  sprintf(buffer, "%f", test_float);
  char buffer1[50];
  double test_float1 = 12345678.9;
  s21_sprintf(buffer1, "%f", test_float1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_f_4) {
  char buffer[50];
  double test_float = -123.456;
  sprintf(buffer, "%f", test_float);
  char buffer1[50];
  double test_float1 = -123.456;
  s21_sprintf(buffer1, "%f", test_float1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(test_s21_sprintf_f_3) {
  char str1[1024] = "\0";
  char str2[1024] = "\0";
  sprintf(str1, "%-15.10f", 1.523451);
  s21_sprintf(str2, "%-15.10f", 1.523451);
  ck_assert_str_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_4) {
  char str1[1024] = "\0";
  char str2[1024] = "\0";
  sprintf(str1, "%.9f", 1000000000.00);
  s21_sprintf(str2, "%.9f", 1000000000.00);
  ck_assert_str_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_6) {
  char str1[1024] = "\0";
  char str2[1024] = "\0";
  sprintf(str1, "%.f", -999.);
  s21_sprintf(str2, "%.f", -999.);
  ck_assert_str_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_7) {
  char str1[400];
  char str2[400];
  char *str3 = "test: %+ 18.0f\ntest: %+10.f\ntest: %+25.f!";
  double num = 7648938790.756589;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_8) {
  char str1[400];
  char str2[400];
  char *str3 = "test: %-15.4f!\ntest: %-26.1f!\ntest: %-18.0f!";
  double num = -365289.3462865487;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_9) {
  char str1[400];
  char str2[400];
  char *str3 = "test: %15.13f!\ntest: %26.15f!";
  double num = -365289.34628654873789362746834;
  ck_assert_int_eq(sprintf(str1, str3, num, num),
                   s21_sprintf(str2, str3, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(test_s21_sprintf_f_10) {
  char str1[400];
  char str2[400];
  char *str3 = "test: %18.7f!\ntest: %10.15f!\ntest: %25.15f!";
  double num = -365289.34628654873789362746834;
  ck_assert_int_eq(sprintf(str1, str3, num, num, num),
                   s21_sprintf(str2, str3, num, num, num));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite *test_s21_sprintf_f(void) {
  Suite *s = suite_create("test_s21_sprintf_f");
  TCase *tc = tcase_create("test_s21_sprintf_f_case");
  tcase_add_test(tc, tc_s21_sprintf_f_1);
  tcase_add_test(tc, tc_s21_sprintf_f_2);
  tcase_add_test(tc, tc_s21_sprintf_f_3);
  tcase_add_test(tc, tc_s21_sprintf_f_4);
  tcase_add_test(tc, test_s21_sprintf_f_3);
  tcase_add_test(tc, test_s21_sprintf_f_4);
  tcase_add_test(tc, test_s21_sprintf_f_6);
  tcase_add_test(tc, test_s21_sprintf_f_7);
  tcase_add_test(tc, test_s21_sprintf_f_8);
  tcase_add_test(tc, test_s21_sprintf_f_9);
  tcase_add_test(tc, test_s21_sprintf_f_10);
  suite_add_tcase(s, tc);
  return (s);
}