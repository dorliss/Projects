#include "test_main.h"

START_TEST(tc_s21_strrchr_1) {
  char* str = "Hello, world!";
  ck_assert_ptr_eq(strrchr(str, 'o'), s21_strrchr(str, 'o'));
}
END_TEST

START_TEST(tc_s21_strrchr_2) {
  char* str = "Hello, world!";
  ck_assert_ptr_null(s21_strrchr(str, 'x'));
}
END_TEST

START_TEST(tc_s21_strrchr_3) {
  char* str = "Hello, world!";
  ck_assert_ptr_eq(strrchr(str, '\0'), s21_strrchr(str, '\0'));
}
END_TEST

START_TEST(tc_s21_strrchr_4) {
  char* str = "";
  ck_assert_ptr_null(s21_strrchr(str, 'a'));
}
END_TEST

START_TEST(tc_s21_strrchr_5) {
  char* str = "Hello, world!";
  ck_assert_ptr_eq(strrchr(str, 'H'), s21_strrchr(str, 'H'));
}
END_TEST

Suite* test_s21_strrchr(void) {
  Suite* s = suite_create("test_s21_strrchr");
  TCase* tc = tcase_create("test_s21_strrchr_case");
  tcase_add_test(tc, tc_s21_strrchr_1);
  tcase_add_test(tc, tc_s21_strrchr_2);
  tcase_add_test(tc, tc_s21_strrchr_3);
  tcase_add_test(tc, tc_s21_strrchr_4);
  tcase_add_test(tc, tc_s21_strrchr_5);
  suite_add_tcase(s, tc);
  return (s);
}