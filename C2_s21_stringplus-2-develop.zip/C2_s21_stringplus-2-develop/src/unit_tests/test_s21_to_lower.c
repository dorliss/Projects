#include "test_main.h"

START_TEST(tc_s21_to_lower_1) {
  char str[] = "Hello world";
  char *res;
  res = s21_to_lower(str);
  ck_assert_str_eq(res, "hello world");
  free(res);
}

START_TEST(tc_s21_to_lower_2) {
  char str[] = "123456";
  char *res = s21_to_lower(str);
  ck_assert_str_eq(str, "123456");
  free(res);
}

Suite *test_s21_to_lower(void) {
  Suite *s = suite_create("test_s21_to_lower");
  TCase *tc = tcase_create("test_s21_to_lower_case");
  tcase_add_test(tc, tc_s21_to_lower_1);
  tcase_add_test(tc, tc_s21_to_lower_2);
  suite_add_tcase(s, tc);
  return (s);
}