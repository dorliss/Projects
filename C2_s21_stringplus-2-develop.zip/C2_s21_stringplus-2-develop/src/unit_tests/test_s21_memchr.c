#include "test_main.h"

START_TEST(tc_s21_memchr_1) {
  char str[] = "Hello, World!";
  char *result = (char *)s21_memchr(str, 'W', s21_strlen(str));
  ck_assert_int_eq(result - str, 7);
  ck_assert_ptr_eq(result, &str[7]);
}
END_TEST

START_TEST(tc_s21_memchr_2) {
  char str[] = "hell, tee22pr";
  char *result = (char *)s21_memchr(str, '2', s21_strlen(str));
  ck_assert_int_eq(result - str, 9);
  ck_assert_ptr_eq(result, &str[9]);
}
END_TEST

START_TEST(tc_s21_memchr_3) {
  char str[] = "ahahakdljfalskjdfakdsjf.lsadkflkad<akdslklafka>";
  char *result = (char *)s21_memchr(str, '<', s21_strlen(str));
  ck_assert_int_eq(result - str, 34);
  ck_assert_ptr_eq(result, &str[34]);
}
END_TEST

START_TEST(tc_s21_memchr_4) {
  char str[] = "ahahakdljfalskjdfakdsjf .lsadkflkad<akdslklafka>";
  char *result = (char *)s21_memchr(str, ' ', s21_strlen(str));
  ck_assert_int_eq(result - str, 23);
  ck_assert_ptr_eq(result, &str[23]);
}
END_TEST

Suite *test_s21_memchr(void) {
  Suite *s = suite_create("test_s21_memchr");
  TCase *tc = tcase_create("test_s21_memchr_case");
  tcase_add_test(tc, tc_s21_memchr_1);
  tcase_add_test(tc, tc_s21_memchr_2);
  tcase_add_test(tc, tc_s21_memchr_3);
  tcase_add_test(tc, tc_s21_memchr_4);
  suite_add_tcase(s, tc);
  return (s);
}