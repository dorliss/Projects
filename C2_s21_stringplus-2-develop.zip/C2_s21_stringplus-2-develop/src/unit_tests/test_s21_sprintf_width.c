#include "test_main.h"

START_TEST(tc_s21_sprintf_width_1) {
  char buffer[20];
  int test_int = 123;
  sprintf(buffer, "%10d", test_int);
  char buffer1[20];
  int test_int1 = 123;
  s21_sprintf(buffer1, "%10d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_width_2) {
  char buffer[20];
  float test_float = 3.14;
  sprintf(buffer, "%10f", test_float);
  char buffer1[20];
  float test_float1 = 3.14;
  s21_sprintf(buffer1, "%10f", test_float1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_width_3) {
  char buffer[20];
  char *test_string = "test";
  sprintf(buffer, "%10s", test_string);
  char buffer1[20];
  char *test_string1 = "test";
  s21_sprintf(buffer1, "%10s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_width_4) {
  char buffer[20];
  float test_float = 3.14;
  sprintf(buffer, "%2f", test_float);
  char buffer1[20];
  float test_float1 = 3.14;
  s21_sprintf(buffer1, "%2f", test_float1);
  ck_assert_str_eq(buffer, "3.140000");
}
END_TEST

Suite *test_s21_sprintf_width(void) {
  Suite *s = suite_create("test_s21_sprintf_width");
  TCase *tc = tcase_create("test_s21_sprintf_width_case");
  tcase_add_test(tc, tc_s21_sprintf_width_1);
  tcase_add_test(tc, tc_s21_sprintf_width_2);
  tcase_add_test(tc, tc_s21_sprintf_width_3);
  tcase_add_test(tc, tc_s21_sprintf_width_4);
  suite_add_tcase(s, tc);
  return (s);
}