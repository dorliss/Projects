#include "test_main.h"

START_TEST(tc_s21_to_upper_1) {
  char str[] = "Hello world";
  char *res = s21_to_upper(str);
  ck_assert_str_eq(res, "HELLO WORLD");
  free(res);
}

START_TEST(tc_s21_to_upper_2) {
  char str[] = "123456";
  char *res = s21_to_upper(str);
  ck_assert_str_eq(res, "123456");
  free(res);
}

Suite *test_s21_to_upper(void) {
  Suite *s = suite_create("test_s21_to_upper");
  TCase *tc = tcase_create("test_s21_to_upper_case");
  tcase_add_test(tc, tc_s21_to_upper_1);
  tcase_add_test(tc, tc_s21_to_upper_2);
  suite_add_tcase(s, tc);
  return (s);
}