#include "test_main.h"

// for 32 bita

START_TEST(tc_s21_sprintf_u_1) {
  char buffer[50];
  unsigned int test_uint = 12345;
  sprintf(buffer, "%u", test_uint);
  char buffer1[50];
  unsigned int test_uint1 = 12345;
  s21_sprintf(buffer1, "%u", test_uint1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_u_2) {
  char buffer[50];
  unsigned int test_uint = 0;
  sprintf(buffer, "%u", test_uint);
  char buffer1[50];
  unsigned int test_uint1 = 0;
  s21_sprintf(buffer1, "%u", test_uint1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_u_3) {
  char buffer[50];
  unsigned int test_uint = 4294967295U;
  sprintf(buffer, "%u", test_uint);
  char buffer1[50];
  unsigned int test_uint1 = 4294967295U;
  s21_sprintf(buffer1, "%u", test_uint1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_u_4) {
  char buffer[50] = "Hello world!";
  unsigned int test_uint = 4294967295U;
  sprintf(buffer, "%u", test_uint);
  char buffer1[50] = "Hello world!";
  unsigned int test_uint1 = 4294967295U;
  s21_sprintf(buffer1, "%u", test_uint1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_u(void) {
  Suite *s = suite_create("test_s21_sprintf_u");
  TCase *tc = tcase_create("test_s21_sprintf_u_case");
  tcase_add_test(tc, tc_s21_sprintf_u_1);
  tcase_add_test(tc, tc_s21_sprintf_u_2);
  tcase_add_test(tc, tc_s21_sprintf_u_3);
  tcase_add_test(tc, tc_s21_sprintf_u_4);
  suite_add_tcase(s, tc);
  return (s);
}