#include "test_main.h"

START_TEST(tc_s21_sprintf_d_1) {
  char buffer[12];
  int test_int = 12345;
  sprintf(buffer, "%d", test_int);
  char buffer1[12];
  int test_int1 = 12345;
  s21_sprintf(buffer1, "%d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_d_2) {
  char buffer[12];
  int test_int = -2147483648;  // int 32 bita
  sprintf(buffer, "%d", test_int);
  char buffer1[12];
  int test_int1 = -2147483648;  // int 32 bita
  s21_sprintf(buffer1, "%d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_d_3) {
  char buffer[12];
  int test_int = 2147483647;  // int 32 bita
  sprintf(buffer, "%d", test_int);
  char buffer1[12];
  int test_int1 = 2147483647;  // int 32 bita
  s21_sprintf(buffer1, "%d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_d_4) {
  char str1[1000];
  char str2[1000];
  char format[] = "This is a simple value %d";
  int val = 69;
  s21_sprintf(str1, format, val);
  sprintf(str2, format, val);
  ck_assert_str_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_5) {
  char str1[100];
  char str2[100];
  char *str3 = "%d Test %d Test %d";
  int val = 012;
  int val2 = -017;
  int val3 = 07464;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_6) {
  char str1[100];
  char str2[100];
  char *str3 = "%ld Test %ld Test %hd GOD %hd";
  long int val = 3088675747373646;
  long val2 = 33030030303;
  short int val3 = 22600;
  short val4 = -120;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_7) {
  char str1[100];
  char str2[100];
  char *str3 = "%3d Test %5d Test %10d";
  int val = -3015;
  int val2 = -11234;
  int val3 = -99;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_8) {
  char str1[200];
  char str2[200];
  char *str3 = "%-10.5d Test %-.8d Test %-7d TEST %-.d";
  int val = -3015;
  int val2 = -712;
  int val3 = -99;
  int val4 = -2939;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_9) {
  char str1[200];
  char str2[200];
  char *str3 = "%0d Test %0.d Test %0.0d TEST %0d GOD %.d";
  int val = -3015;
  int val2 = -712;
  int val3 = -99;
  int val4 = -2939;
  int val5 = -0123;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_10) {
  char str1[200];
  char str2[200];
  char *str3 = "%+d Test %+3.d Test %+5.7d TEST %+10d";
  int val = -3015;
  int val2 = -712;
  int val3 = -99;
  int val4 = -2939;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4),
                   s21_sprintf(str2, str3, val, val2, val3, val4));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_11) {
  char str1[200];
  char str2[200];
  char *str3 = "%d Test %3.d Test %5.7d TEST %10d %#d %-d %+d %.d % .d";
  int val = 0;
  ck_assert_int_eq(
      sprintf(str1, str3, val, val, val, val, val, val, val, val, val),
      s21_sprintf(str2, str3, val, val, val, val, val, val, val, val, val,
                  val));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_d_12) {
  char str1[200];
  char str2[200];
  char *str3 = "%6.5d Test %.23d Test %3.d TEST %.d %.6d";
  int val = -3015;
  int val2 = -712;
  int val3 = -99;
  int val4 = -38;
  int val5 = -100;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3, val4, val5),
                   s21_sprintf(str2, str3, val, val2, val3, val4, val5));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite *test_s21_sprintf_d(void) {
  Suite *s = suite_create("test_s21_sprintf_d");
  TCase *tc = tcase_create("test_s21_sprintf_d_case");
  tcase_add_test(tc, tc_s21_sprintf_d_1);
  tcase_add_test(tc, tc_s21_sprintf_d_2);
  tcase_add_test(tc, tc_s21_sprintf_d_3);
  tcase_add_test(tc, tc_s21_sprintf_d_4);
  tcase_add_test(tc, tc_s21_sprintf_d_5);
  tcase_add_test(tc, tc_s21_sprintf_d_6);
  tcase_add_test(tc, tc_s21_sprintf_d_7);
  tcase_add_test(tc, tc_s21_sprintf_d_8);
  tcase_add_test(tc, tc_s21_sprintf_d_9);
  tcase_add_test(tc, tc_s21_sprintf_d_10);
  tcase_add_test(tc, tc_s21_sprintf_d_11);
  tcase_add_test(tc, tc_s21_sprintf_d_12);
  suite_add_tcase(s, tc);
  return (s);
}