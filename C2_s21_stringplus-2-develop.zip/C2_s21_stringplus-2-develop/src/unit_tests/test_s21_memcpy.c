#include "test_main.h"

START_TEST(test_s21_memcpy_1) {
  char str1[] = "Hello, World";
  char copied_original[20];
  s21_memcpy(copied_original, str1, sizeof(str1));
  char copied_original1[20];
  memcpy(copied_original1, str1, sizeof(str1));
  ck_assert_str_eq(copied_original1, copied_original);
}
END_TEST

START_TEST(test_s21_memcpy_2) {
  char str1[] = "";
  char copied_original[20];
  s21_memcpy(copied_original, str1, sizeof(str1));
  char copied_original1[20];
  memcpy(copied_original1, str1, sizeof(str1));
  ck_assert_str_eq(copied_original1, copied_original);
}
END_TEST

START_TEST(test_s21_memcpy_3) {
  char str1[] = "\n";
  char copied_original[20];
  s21_memcpy(copied_original, str1, sizeof(str1));
  char copied_original1[20];
  memcpy(copied_original1, str1, sizeof(str1));
  ck_assert_str_eq(copied_original1, copied_original);
}
END_TEST

START_TEST(test_s21_memcpy_4) {
  char str1[] = "hahsahashas\npsapaspasppas";
  char copied_original[100];
  s21_memcpy(copied_original, str1, sizeof(str1));
  char copied_original1[100];
  memcpy(copied_original1, str1, sizeof(str1));
  ck_assert_str_eq(copied_original1, copied_original);
}
END_TEST

Suite *test_s21_memcpy(void) {
  Suite *s = suite_create("test_s21_memcpy");
  TCase *tc = tcase_create("test_s21_memcpy_case");
  tcase_add_test(tc, test_s21_memcpy_1);
  tcase_add_test(tc, test_s21_memcpy_2);
  tcase_add_test(tc, test_s21_memcpy_3);
  tcase_add_test(tc, test_s21_memcpy_4);
  suite_add_tcase(s, tc);
  return (s);
}