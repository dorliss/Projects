#include "test_main.h"

START_TEST(tc_s21_strncpy_1) {
  char str[10];
  strncpy(str, "Hello", 10);
  char str1[10];
  s21_strncpy(str1, "Hello", 10);
  ck_assert_str_eq(str, str1);
  ck_assert_int_eq(str[5], str1[5]);
}
END_TEST

START_TEST(tc_s21_strncpy_2) {
  char str[6];
  strncpy(str, "Hello", 6);
  char str1[6];
  s21_strncpy(str1, "Hello", 6);
  ck_assert_str_eq(str, str1);
}
END_TEST

START_TEST(tc_s21_strncpy_4) {
  char str[10];
  strncpy(str, "", 10);
  char str1[10];
  s21_strncpy(str1, "", 10);
  ck_assert_str_eq(str, str1);
  ck_assert_int_eq(str[0], str1[0]);
}
END_TEST

Suite *test_s21_strncpy(void) {
  Suite *s = suite_create("test_s21_strncpy");
  TCase *tc = tcase_create("test_s21_strncpy_case");
  tcase_add_test(tc, tc_s21_strncpy_1);
  tcase_add_test(tc, tc_s21_strncpy_2);
  tcase_add_test(tc, tc_s21_strncpy_4);
  suite_add_tcase(s, tc);
  return (s);
}