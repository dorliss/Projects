#include "test_main.h"

// idk what i can add more...

START_TEST(tc_s21_sprintf_percent_1) {
  char buffer[20];
  sprintf(buffer, "%%");
  char buffer1[20];
  s21_sprintf(buffer1, "%%");
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_2) {
  char buffer[20];
  char *test_string = "Hello";
  sprintf(buffer, "%%%s", test_string);
  char buffer1[20];
  char *test_string1 = "Hello";
  s21_sprintf(buffer1, "%%%s", test_string1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_3) {
  char buffer[20];
  int test = 123;
  sprintf(buffer, "%%%d", test);
  char buffer1[20];
  int test1 = 123;
  s21_sprintf(buffer1, "%%%d", test1);
  ck_assert_str_eq(buffer1, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_4) {
  char buffer[20];
  int test = 123;
  sprintf(buffer, "%%%d%%", test);
  char buffer1[20];
  int test1 = 123;
  s21_sprintf(buffer1, "%%%d%%", test1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_5) {
  char str1[100] = "";
  char str2[100] = "";
  char *str3 = "%%Test %o Test";
  int val = 012;
  ck_assert_int_eq(sprintf(str1, str3, val), s21_sprintf(str2, str3, val));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_6) {
  char str1[100];
  char str2[100];
  char *str3 = "Test %o Tes%%%%t %o";
  int val = 012;
  int val2 = 017;
  ck_assert_int_eq(sprintf(str1, str3, val, val2),
                   s21_sprintf(str2, str3, val, val2));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

START_TEST(tc_s21_sprintf_percent_7) {
  char str1[100];
  char str2[100];
  char *str3 = "%o Te%%st %o Test %o";
  int val = 3015;
  int val2 = 712;
  int val3 = 99;
  ck_assert_int_eq(sprintf(str1, str3, val, val2, val3),
                   s21_sprintf(str2, str3, val, val2, val3));
  ck_assert_pstr_eq(str1, str2);
}
END_TEST

Suite *test_s21_sprintf_percent(void) {
  Suite *s = suite_create("test_s21_sprintf_percent");
  TCase *tc = tcase_create("test_s21_sprintf_percent_case");
  tcase_add_test(tc, tc_s21_sprintf_percent_1);
  tcase_add_test(tc, tc_s21_sprintf_percent_2);
  tcase_add_test(tc, tc_s21_sprintf_percent_3);
  tcase_add_test(tc, tc_s21_sprintf_percent_4);
  tcase_add_test(tc, tc_s21_sprintf_percent_5);
  tcase_add_test(tc, tc_s21_sprintf_percent_6);
  tcase_add_test(tc, tc_s21_sprintf_percent_7);
  suite_add_tcase(s, tc);
  return (s);
}