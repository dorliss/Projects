#include "test_main.h"

START_TEST(tc_s21_strchr_1) {
  char *str = "testing";
  char *result = strchr(str, 'e');
  char *result1 = s21_strchr(str, 'e');
  ck_assert_str_eq(result, result1);
}
END_TEST

START_TEST(tc_s21_strchr_2) {
  char *str = "test";
  char *result = s21_strchr(str, 'x');
  ck_assert_ptr_null(result);
}
END_TEST

START_TEST(tc_s21_strchr_3) {
  char *str = "";
  char *result = s21_strchr(str, 'a');
  ck_assert_ptr_null(result);
}
END_TEST

START_TEST(tc_s21_strchr_4) {
  char str[] = "test\0opa";
  char *result = strchr(str, '\0');
  char *result1 = s21_strchr(str, '\0');
  ck_assert_str_eq(result, result1);
}
END_TEST

Suite *test_s21_strchr(void) {
  Suite *s = suite_create("test_s21_strchr");
  TCase *tc = tcase_create("test_s21_strchr_case");
  tcase_add_test(tc, tc_s21_strchr_1);
  tcase_add_test(tc, tc_s21_strchr_2);
  tcase_add_test(tc, tc_s21_strchr_3);
  tcase_add_test(tc, tc_s21_strchr_4);
  suite_add_tcase(s, tc);
  return (s);
}