#include "test_main.h"

START_TEST(tc_s21_strcspn_1) {
  char str1[] = "abcd";
  char str2[] = "xyz";
  ck_assert_uint_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
}
END_TEST

START_TEST(tc_s21_strcspn_2) {
  char str1[] = "";
  char str2[] = "abc";
  ck_assert_uint_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
}
END_TEST

START_TEST(tc_s21_strcspn_3) {
  char str1[] = "abc";
  char str2[] = "";
  ck_assert_uint_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
}
END_TEST

START_TEST(tc_s21_strcspn_4) {
  char str1[] = "abc";
  char str2[] = "axyz";
  ck_assert_uint_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
}
END_TEST

START_TEST(tc_s21_strcspn_5) {
  char str1[] = "abcabc";
  char str2[] = "abc";
  ck_assert_uint_eq(strcspn(str1, str2), s21_strcspn(str1, str2));
}
END_TEST

Suite *test_s21_strcspn(void) {
  Suite *s = suite_create("test_s21_strcspn");
  TCase *tc = tcase_create("test_s21_strcspn_case");
  tcase_add_test(tc, tc_s21_strcspn_1);
  tcase_add_test(tc, tc_s21_strcspn_2);
  tcase_add_test(tc, tc_s21_strcspn_3);
  tcase_add_test(tc, tc_s21_strcspn_4);
  tcase_add_test(tc, tc_s21_strcspn_5);
  suite_add_tcase(s, tc);
  return (s);
}