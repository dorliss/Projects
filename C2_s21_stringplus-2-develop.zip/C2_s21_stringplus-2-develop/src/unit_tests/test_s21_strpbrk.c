#include "test_main.h"

START_TEST(tс_s21_strpbrk_1) {
  char *str1 = strpbrk("Hello World", "o");
  char *str2 = s21_strpbrk("Hello World", "o");
  ck_assert_ptr_eq(str1, str2);
}
END_TEST

START_TEST(tс_s21_strpbrk_2) {
  const char *str1 = s21_strpbrk("Hello World", "x");
  ck_assert_ptr_null(str1);
}
END_TEST

START_TEST(tс_s21_strpbrk_3) {
  const char *str1 = s21_strpbrk("", "o");
  ck_assert_ptr_null(str1);
}
END_TEST

START_TEST(tс_s21_strpbrk_4) {
  const char *str1 = s21_strpbrk("Hello World", "");
  ck_assert_ptr_null(str1);
}
END_TEST

START_TEST(tс_s21_strpbrk_5) {
  const char *str1 = s21_strpbrk("", "");
  ck_assert_ptr_null(str1);
}
END_TEST

START_TEST(tс_s21_strpbrk_6) {
  char *str1 = strpbrk("Hello World", "le");
  char *str2 = s21_strpbrk("Hello World", "le");
  ck_assert_ptr_eq(str1, str2);
}
END_TEST

Suite *test_s21_strpbrk(void) {
  Suite *s = suite_create("test_s21_strpbrk");
  TCase *tc = tcase_create("test_s21_strpbrk_case");
  tcase_add_test(tc, tс_s21_strpbrk_1);
  tcase_add_test(tc, tс_s21_strpbrk_2);
  tcase_add_test(tc, tс_s21_strpbrk_3);
  tcase_add_test(tc, tс_s21_strpbrk_4);
  tcase_add_test(tc, tс_s21_strpbrk_5);
  tcase_add_test(tc, tс_s21_strpbrk_6);
  suite_add_tcase(s, tc);
  return (s);
}