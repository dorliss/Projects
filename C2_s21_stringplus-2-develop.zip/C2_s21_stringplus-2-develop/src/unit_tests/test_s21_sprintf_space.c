#include "test_main.h"

START_TEST(tc_s21_sprintf_space_1) {
  char buffer[20];
  int test_int = 123;
  sprintf(buffer, "% d", test_int);
  char buffer1[20];
  int test_int1 = 123;
  s21_sprintf(buffer1, "% d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_space_2) {
  char buffer[20];
  int test_int = -123;
  sprintf(buffer, "% d", test_int);
  char buffer1[20];
  int test_int1 = -123;
  s21_sprintf(buffer1, "% d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_space_3) {
  char buffer[20];
  int test_int = 0;
  sprintf(buffer, "% d", test_int);
  char buffer1[20];
  int test_int1 = 0;
  s21_sprintf(buffer1, "% d", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_space_4) {
  char buffer[20];
  float test_int = 3.14;
  sprintf(buffer, "% f", test_int);
  char buffer1[20];
  float test_int1 = 3.14;
  s21_sprintf(buffer1, "% f", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

START_TEST(tc_s21_sprintf_space_5) {
  char buffer[20];
  float test_int = -3.14;
  sprintf(buffer, "% f", test_int);
  char buffer1[20];
  float test_int1 = -3.14;
  s21_sprintf(buffer1, "% f", test_int1);
  ck_assert_str_eq(buffer, buffer1);
}
END_TEST

Suite *test_s21_sprintf_space(void) {
  Suite *s = suite_create("test_s21_sprintf_space");
  TCase *tc = tcase_create("test_s21_sprintf_space_case");
  tcase_add_test(tc, tc_s21_sprintf_space_1);
  tcase_add_test(tc, tc_s21_sprintf_space_2);
  tcase_add_test(tc, tc_s21_sprintf_space_3);
  tcase_add_test(tc, tc_s21_sprintf_space_4);
  tcase_add_test(tc, tc_s21_sprintf_space_5);
  suite_add_tcase(s, tc);
  return (s);
}