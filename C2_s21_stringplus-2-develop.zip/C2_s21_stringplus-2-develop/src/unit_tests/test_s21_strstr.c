#include "test_main.h"

START_TEST(tc_s21_strstr_1) {
  char* str = "Hello, world!";
  ck_assert_ptr_eq(strstr(str, "world"), s21_strstr(str, "world"));
}
END_TEST

START_TEST(tc_s21_strstr_2) {
  char* str = "Hello, world!";
  ck_assert_ptr_null(s21_strstr(str, "test"));
}
END_TEST

START_TEST(tc_s21_strstr_3) {
  char* str = "Hello, world!";
  ck_assert_ptr_eq(strstr(str, ""), s21_strstr(str, ""));
}
END_TEST

START_TEST(tc_s21_strstr_4) {
  char* str = "";
  ck_assert_ptr_null(s21_strstr(str, "Hello"));
}
END_TEST

START_TEST(tc_s21_strstr_5) {
  char* str = "Hello";
  ck_assert_ptr_null(s21_strstr(str, "Hello, world!"));
}
END_TEST

Suite* test_s21_strstr(void) {
  Suite* s = suite_create("test_s21_strstr");
  TCase* tc = tcase_create("test_s21_strstr_case");
  tcase_add_test(tc, tc_s21_strstr_1);
  tcase_add_test(tc, tc_s21_strstr_2);
  tcase_add_test(tc, tc_s21_strstr_3);
  tcase_add_test(tc, tc_s21_strstr_4);
  tcase_add_test(tc, tc_s21_strstr_5);
  suite_add_tcase(s, tc);
  return (s);
}