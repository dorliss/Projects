#include "test_main.h"

START_TEST(tc_s21_strlen_1) {
  char *str = "Example";
  ck_assert_uint_eq(strlen(str), s21_strlen(str));
}
END_TEST

START_TEST(tc_s21_strlen_2) {
  char *str = "";
  ck_assert_uint_eq(strlen(str), s21_strlen(str));
}
END_TEST

START_TEST(tc_s21_strlen_3) {
  char str[SIZE_MAX_MEMSET];
  memset(str, 'a', SIZE_MAX_MEMSET - 1);
  str[SIZE_MAX_MEMSET - 1] = '\0';
  ck_assert_uint_eq(strlen(str), s21_strlen(str));  // SIZE_MAX_MEMSET - 1
}
END_TEST

START_TEST(tc_s21_strlen_4) {
  char *str = "Hello\nman";
  ck_assert_uint_eq(strlen(str), s21_strlen(str));  // 9
}

Suite *test_s21_strlen(void) {
  Suite *s = suite_create("test_s21_strlen");
  TCase *tc = tcase_create("test_s21_strlen_case");
  tcase_add_test(tc, tc_s21_strlen_1);
  tcase_add_test(tc, tc_s21_strlen_2);
  tcase_add_test(tc, tc_s21_strlen_3);
  tcase_add_test(tc, tc_s21_strlen_4);
  suite_add_tcase(s, tc);
  return (s);
}