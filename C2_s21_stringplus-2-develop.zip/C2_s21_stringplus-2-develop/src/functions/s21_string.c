#include "../s21_string.h"

s21_size_t s21_strlen(const char *str) {
  s21_size_t len = 0;
  for (; str[len]; len++) {
  }
  return len;
}
// Выполняет поиск первого вхождения символа c (беззнаковый тип) в первых n
// байтах строки, на которую указывает аргумент str.
void *s21_memchr(const void *str, int c, s21_size_t n) {
  const unsigned char *s = str;
  unsigned char mc = c;

  for (s21_size_t i = 0; i < n; i++) {
    if (s[i] == mc) return (void *)(s + i);
  }
  return NULL;
}

// Сравнивает первые n байтов str1 и str2.
int s21_memcmp(const void *str1, const void *str2, s21_size_t n) {
  int raz = 0;
  const unsigned char *s1 = str1;
  const unsigned char *s2 = str2;
  for (int i = 0; i < (int)n; i++) {
    if (s1[1] != s2[i]) {
      raz = s1[i] - s2[i];
      break;
    }
  }
  return raz;
}

void *s21_memcpy(void *dest, const void *src, s21_size_t n) {
  for (s21_size_t i = 0; i < n; i++) {
    ((char *)dest)[i] = ((char *)src)[i];
  }
  return dest;
}

void *s21_memset(void *str, int c, s21_size_t n) {
  char *nStr = str;
  for (s21_size_t i = 0; i < n; i++) {
    (*(nStr + i)) = (char)c;
  }
  return (void *)nStr;
}

char *s21_strncat(char *dest, const char *src, s21_size_t n) {
  s21_size_t dest_lenght = s21_strlen(dest);
  s21_size_t i = 0;
  for (i = 0; i < n && src[i] != '\0'; i++) {
    dest[dest_lenght + i] = src[i];
  }
  dest[dest_lenght + i] = '\0';
  return dest;
}

char *s21_strchr(const char *str, int c) {
  for (s21_size_t i = 0; i <= s21_strlen(str); i++) {
    if (str[i] == c) return (char *)str + i;
  }
  return NULL;
}

int s21_strncmp(const char *str1, const char *str2, s21_size_t n) {
  s21_size_t i = 0;
  if (n > s21_strlen(str1) && n > s21_strlen(str2)) n = s21_strlen(str1);
  while ((*(char *)(str1 + i) == *(char *)(str2 + i)) && i < n) i++;
  return (i == n) ? 0 : (*(char *)(str1 + i) - *(char *)(str2 + i));
}

char *s21_strncpy(char *dest, const char *src, s21_size_t n) {
  for (s21_size_t i = 0; i < n; i++) {
    dest[i] = src[i];
  }
  return dest;
}

s21_size_t s21_strcspn(const char *str1, const char *str2) {
  s21_size_t kol = 0;
  int flag = 1;
  for (s21_size_t i = 0; i < s21_strlen(str1); i++) {
    for (s21_size_t j = 0; j < s21_strlen(str2); j++) {
      if (str1[i] == str2[j]) flag = 0;
    }
    if (flag == 1) kol++;
  }
  return kol;
}

char *s21_strerror(int errnum) {
  char *res = s21_NULL;
  static char s21_buff[1024] = {'\0'};
  if (errnum < 0 || errnum >= S21_ERROR_LIST) {
    s21_sprintf(s21_buff, "Unknown error %d", errnum);
    //  replace with our sprintf and add ifndef on linux and mac
    res = s21_buff;
  } else {
    res = (char *)s21_error_list[errnum];
  }
  return res;
}

char *s21_strpbrk(const char *str1, const char *str2) {
  char *answer = s21_NULL;
  int len_str2 = s21_strlen(str2);
  while (*str1 && !answer) {
    for (int t = 0; t < len_str2; t++) {
      if (*str1 == str2[t]) {
        answer = (char *)str1;
        break;
      }
    }
    if (!answer) str1++;
  }
  return answer;
}

char *s21_strrchr(const char *str, int c) {
  const char *ptr = str;
  int f = 0;
  while (*str) {
    str++;
  }
  while (str >= ptr && f == 0) {
    if (*str == (char)c) {
      f = 1;
    } else {
      str--;
    }
  }
  return f ? (char *)str : s21_NULL;
}

char *s21_strstr(const char *haystack, const char *needle) {
  s21_size_t needle_len = s21_strlen(needle);
  int flag = 1;
  if (needle_len) {
    flag = 0;
    s21_size_t haystack_len = s21_strlen(haystack);
    while (haystack_len-- >= needle_len && flag == 0) {
      if (!s21_memcmp(haystack, needle, needle_len))
        flag = 1;
      else
        haystack++;
    }
  }
  return flag ? (char *)haystack : s21_NULL;
}

char *s21_strtok(char *str, const char *delim) {
  static char *ptr = s21_NULL;
  if (str == s21_NULL) str = ptr;
  while ((str != NULL) && (*str != '\0') && (s21_strchr(delim, *str) != NULL)) {
    str++;
  }
  if (str && *str == '\0') {
    str = s21_NULL;
    ptr = s21_NULL;
  }
  if (str && *str != '\0') {
    ptr = str;
    while (*ptr && !(s21_strchr(delim, *ptr))) {
      ptr++;
    }
  }
  if (ptr && *ptr) {
    *ptr = '\0';
    ptr++;
  }
  return str;
}

void *s21_to_upper(const char *str) {
  if (str == NULL) {
    return NULL;
  }

  int length = s21_strlen(str);
  char *upper_str =
      (char *)malloc(length + 1);  // add 1 for the null-terminating character
  if (upper_str == NULL) {
    return NULL;
  }

  for (int i = 0; i < length; i++) {
    if (str[i] >= 'a' &&
        str[i] <= 'z')  // check if the character is a lowercase letter
    {
      upper_str[i] = str[i] - 32;  // convert to uppercase
    } else {
      upper_str[i] = str[i];
    }
  }

  upper_str[length] = '\0';  // add the null-terminating character
  return upper_str;
}

void *s21_to_lower(const char *str) {
  if (str == NULL) {
    return NULL;
  }

  int length = s21_strlen(str);
  char *lower_str =
      (char *)malloc(length + 1);  // add 1 for the null-terminating character
  if (lower_str == NULL) {
    return NULL;
  }

  for (int i = 0; i < length; i++) {
    if (str[i] >= 'A' &&
        str[i] <= 'Z')  // check if the character is a lowercase letter
    {
      lower_str[i] = str[i] + 32;  // convert to uppercase
    } else {
      lower_str[i] = str[i];
    }
  }

  lower_str[length] = '\0';  // add the null-terminating character
  return lower_str;
}

// Возвращает новую строку, в которой указанная строка (str) вставлена в
// указанную позицию (start_index) в данной строке (src). В случае какой-либо
// ошибки следует вернуть значение NULL
void *s21_insert(const char *src, const char *str, s21_size_t start_index) {
  char *new_str = s21_NULL;
  if (src != s21_NULL && str != s21_NULL && start_index <= s21_strlen(src)) {
    int all_length = s21_strlen(src) + s21_strlen(str);
    new_str = malloc(sizeof(char) * (all_length + 1));
    // new_str = (char *)realloc(new_str, all_length);
    int src_len = s21_strlen(src);
    int str_len = s21_strlen(str);
    for (s21_size_t i = 0; i < start_index; i++) {
      new_str[i] = src[i];
    }

    for (int i = 0; i < str_len; i++) {
      new_str[start_index + i] = str[i];
    }
    for (int i = (int)start_index; i < src_len; i++) {
      new_str[i + str_len] = src[i];
    }
    new_str[all_length] = '\0';
  }
  return new_str;
}

void *s21_trim(const char *src, const char *trim_chars) {
  char *new_str = S21_NULL;
  if (src) {
    if (trim_chars && *trim_chars) {
      s21_size_t len = s21_strlen(src);
      s21_size_t chars_len = s21_strlen(trim_chars);
      s21_trim_left(&src, trim_chars, &len, chars_len);
      if (len) {
        s21_trim_right(&src, trim_chars, &len, chars_len);
      }
      new_str = (char *)malloc(sizeof(char) * (len + 1));
      if (new_str) {
        for (s21_size_t i = 0; i < len + 1; i++) {
          if (i < len) {
            new_str[i] = src[i];
          } else {
            new_str[i] = '\0';
          }
        }
      }
    } else {
      new_str = s21_trim(src, " \t\n");
    }
  }
  return new_str;
}

void s21_trim_left(const char **src, const char *trim_chars,
                   s21_size_t *src_len, const s21_size_t trim_chars_len) {
  s21_size_t len = 0;
  while (src && len != trim_chars_len) {
    if ((**src) == trim_chars[len]) {
      (*src)++;
      (*src_len) -= 1;
      len = 0;
      continue;
    }
    len++;
  }
}

void s21_trim_right(const char **src, const char *trim_chars,
                    s21_size_t *src_len, const s21_size_t trim_chars_len) {
  s21_size_t len = 0;
  s21_size_t i = (*src_len) - 1;
  while (src && len != trim_chars_len) {
    if ((*src)[i] == trim_chars[len]) {
      i--;
      (*src_len)--;
      len = 0;
      continue;
    }
    len++;
  }
}