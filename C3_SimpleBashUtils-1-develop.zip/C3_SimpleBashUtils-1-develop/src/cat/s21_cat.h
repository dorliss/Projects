#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

struct Options {
  int b;
  int e;
  int n;
  int s;
  int t;
  int v;
  int E;
  int T;
};

int parse_flags(int argc, char **argv, struct Options *opt);
int print_content(struct Options *opt, char **argv);
int is_regular_file(char *filename);