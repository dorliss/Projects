#include "s21_cat.h"

struct Options opt = {
    .b = 0,  //нумерует только пустые строки
    .e = 0,  //также отображает символы конца строки как $
    .n = 0,  //нумерует все выходные строки
    .s = 0,  //сжимает несколько смежных пустых строк
    .t = 0,  //также отображает табы как ^I
    .v = 0,  // Display non-printing characters so they are visible.  Control
             // characters print as `^X' for control-X; the delete character
             // (octal 0177) prints as `^?'.  Non-ASCII characters (with the
             // high bit set) are printed as `M-' (for meta) followed by the
             // character for the low 7 bits.(ВЗЯТО С МАНУАЛА) Дополнительный
             // флаг для -е и -t
    .E = 0,  // GNU -e, но без -v
    .T = 0,  // GNU -t но без -v
};
int main(int argc, char *argv[]) {
  if (parse_flags(argc, argv, &opt) == 1) {
    while (optind < argc) {
      int res = print_content(&opt, argv);
      if (res == -1) {
        fprintf(stderr, "cat: %s: No such file or directory",
                argv[optind]);  // optind-это индекс следующего обрабатываемого
                                // элемента argv
      }

      if (res == -2) {
        fprintf(stderr, "cat: %s: Is a directory", argv[optind]);
      }
      optind++;
    }
  }
}

int parse_flags(int argc, char *argv[], struct Options *opt) {
  int flag = 1;
  int rez = 0;
  int optionIndex = 0;
  const struct option arr[] = {{"number", 0, NULL, 'n'},
                               {"number-nonblank", 0, NULL, 'b'},
                               {"squeeze-blank", 0, NULL, 's'}};

  while ((rez = getopt_long(argc, argv, "vbenstET", arr, &optionIndex)) != -1) {
    switch (rez) {
      case 'v': {
        opt->v = 1;
        break;
      };

      case 'b': {
        opt->b = 1;
        break;
      };

      case 'e': {
        opt->e = 1;
        opt->v = 1;
        break;
      };

      case 'n': {
        opt->n = 1;
        break;
      };

      case 's': {
        opt->s = 1;
        break;
      };

      case 't': {
        opt->t = 1;
        opt->v = 1;
        break;
      }

      case 'E': {
        opt->E = 1;
        opt->v = 0;
        break;
      };

      case 'T': {
        opt->T = 1;
        opt->v = 0;
        break;
      };

      default: {
        flag = rez;
        fprintf(stderr, "usage: cat [-benstuv] [file ...]");
        break;
      };
    }
  }
  return flag;
}

int print_content(struct Options *opt, char **argv) {
  int flag = 1;
  FILE *f;
  char ch = '\n';
  char ch2;
  int strCount = 0;
  int counter = 1;
  if ((f = fopen(argv[optind], "r")) !=
      NULL) {  // optind-это индекс следующего обрабатываемого элемента argv
    if (is_regular_file(argv[optind])) {  //проверка на файл или директорию
      while ((ch2 = fgetc(f)) != EOF) {  // E0F-конец файла
        if (opt->s && ch == '\n' && ch2 == '\n') {
          strCount++;
          if (strCount > 1) {
            continue;
          }
        }

        if ((opt->n && ch == '\n' && !opt->b) ||
            ((opt->b) && ch == '\n' && ch2 != '\n')) {
          printf("%6d\t", counter++);
        }

        if (opt->e == 1 && ch2 == '\n') {
          printf("$");
        }

        if (opt->t && ch2 == '\t') {
          printf("^");
          ch2 = 'I';
        }

        if (opt->v && !(ch2 >= 32 && ch2 < 127) && ch2 != '\n' && ch2 != '\t') {
          if (ch2 == 127) {
            printf("^");
            ch2 -= 64;
          } else if (ch2 < 32 && ch2 >= 0) {
            printf("^");
            ch2 += 64;
          }
        }

        if (ch == '\n' && ch2 != '\n') {
          strCount = 0;
        }
        ch = ch2;
        printf("%c", ch2);
      }
      fclose(f);
    } else {
      flag = -2;
    }
  } else {
    flag = -1;
  }
  return flag;
}

int is_regular_file(char *filename) {
  struct stat file_stat;
  stat(filename, &file_stat);
  return S_ISREG(file_stat.st_mode);
}