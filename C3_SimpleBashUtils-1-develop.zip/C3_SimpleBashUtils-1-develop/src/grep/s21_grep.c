#include "s21_grep.h"

struct Options opt = {
    .e = 0,  // поиск файла по шаблону
    .i = 0,  // посик по слову игнорируя регистр
    .v = 0,  // ищет все строки кроме заданой
    .c = 0,  // выводит количество совпадений
    .l = 0,  // выводит только название файла с совпадением
    .n = 0,  // выводит номер строчки где был найдено совпадение
    .h = 0,  // подавляет вывод название файла где был найдено вхождение
    .s =
        0,  // не выводит предупреждение о несуществующем или о нечитаемом файле
    .f = 0,  // берет шаблоны из файла
    .o = 0,  // выводит сам шаблон при совпадении
    .noOpt = 0,
    .notOneFile = 0};

int main(int argc, char *argv[]) {
  parse_flags(argc, argv, &opt);
  char *pattern = argv[optind];
  while (optind < argc) {
    print_content(opt, pattern, argv[optind]);
    optind++;
  }
}

int parse_flags(int argc, char **argv, struct Options *opt) {
  int flag = 1;
  int res;
  int optionIndex = 0;
  const struct option arr[] = {{NULL, 0, NULL, 0}};
  while ((res = getopt_long(argc, argv, "efivclnhsfo", arr, &optionIndex)) !=
         -1) {
    opt->e = 1;
    switch (res) {
      case 'i': {
        opt->i = 1;
        break;
      };

      case 'e': {
        opt->e = 1;
        opt->f = 0;
        break;
      };

      case 'h': {
        opt->h = 1;
        break;
      }

      case 'v': {
        opt->v = 1;
        break;
      }

      case 'c': {
        opt->c = 1;
        break;
      }

      case 'l': {
        opt->l = 1;
        break;
      }

      case 'n': {
        opt->n = 1;
        break;
      }

      case 'f': {
        opt->e = 0;
        opt->f = 1;
        break;
      }

      case 's': {
        opt->s = 1;
        opterr = 0;
        break;
      }

      case 'o': {
        opt->o = 1;
        break;
      }
      default: {
        flag = res;
        fprintf(stderr, "usage: cat [-benstuv] [file ...]");
        break;
      }
    }
  }
  return flag;
}

int print_content(struct Options opt, char *pattern, char *file) {
  char str[9999];
  int counter = 0;
  int counterString = 0;
  regex_t reegex;
  regcomp(&reegex, pattern,
          REG_EXTENDED);  //использовать синтаксис расширенных регулярных
                          //рыражений POSIX во время интерпретации regex. Если
                          //не включен этот флаг, то используется синтаксис
                          //простых регулярных выражений POSIX
  FILE *f;
  int resSearch;

  if ((f = fopen(file, "r")) != NULL) {
    while ((fgets(str, 9999, f)) != NULL) {
      counterString++;
      resSearch = regexec(&reegex, str, 0, NULL, 0);

      if (opt.i) {
        regfree(&reegex);
        regcomp(&reegex, pattern,
                REG_ICASE);  //не учитывать регистр. Последующие поиски regexec
                             //с использованием данного буферного шаблона не
                             //будут зависеть от регистра
        resSearch = regexec(&reegex, str, 0, NULL, 0);
      }

      if (opt.v) {
        resSearch = !resSearch;
      }

      if (opt.h) {
        opt.notOneFile = 0;
      }

      if (resSearch == 0) {
        counter++;
        if (str[strlen(str) - 1] != '\n') {
          int end = strlen(str);
          str[end] = '\n';
          str[end + 1] = '\0';
        }

        if (opt.c != 1 && opt.l != 1) {
          if (opt.notOneFile && opt.n) {
            printf("%s:%d:%s", file, counterString, str);
          } else if (opt.notOneFile && !opt.n) {
            printf("%s:%s", file, str);
          } else if (!opt.notOneFile && opt.n) {
            printf("%d:%s", counterString, str);
          } else {
            printf("%s", str);
          }
        }
      }
    }

    if (opt.c && !opt.l) {
      if (opt.notOneFile) {
        printf("%s:%d\n", file, counter);
      } else {
        printf("%d\n", counter);
      }
    }

    if (opt.c && opt.l) {
      if (counter == 0) {
        counter = 0;
      } else {
        counter = 1;
      }
      if (opt.notOneFile) {
        printf("%s:%d\n", file, counter);
      } else {
        printf("%d\n", counter);
      }
    }

    if (opt.l && counter != 0) {
      counter = 1;
      printf("%s\n", file);
    }
    fclose(f);
  }

  regfree(&reegex);
  return 1;
}